<?php

    define('ARTICLE_DOC','doc_article');
    define('ARTICLE_DOC_TRANSLATION','doc_article_translation');
    define('PUBLICATION_DOC','doc_publication');
    define('PUBLICATION_DOC_TRANSLATION','doc_publication_translation');

    define('ARTWORK_ARTICLE_DOC','doc_artwork_article');
    define('ARTWORK_ARTICLE_DOC_TRANSLATION','doc_artwork_article_translation');
    define('ARTWORK_PUBLICATION_DOC','doc_artwork_publication');
    define('ARTWORK_PUBLICATION_DOC_TRANSLATION','doc_artwork_publication_translation');
