<footer role="contentinfo">
    <div class="container clearfix">
        <div class="col-md-6 copyrightinfo">
            Copyrights © 2016 ESE Law<br>
            <div id="copyright-links">
                <a href="terms-of-use.html">Terms of Use</a> / <a href="privacy-policy.html">Privacy Policy</a> / <a href="about-us.html">About Us</a>
            </div>
        </div>
        <div class="col-md-6 contactinfo">
            <div class="pull-right">
                <a href="mailto:info@eselaw.com">info@eselaw.com</a> · +1 (917) 250-0517
            </div>
        </div>
    </div>
</footer>